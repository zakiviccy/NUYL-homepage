﻿A template file is ComEX_template.tex, which includes the class file "comex.cls."
For bibtex users, "comex.bst" is available, and its sample source is "mybib.bib."
These bibtex files are contributed by Dr. Ryutaro Matsumoto.

To Authors: 
  General questions about the TeX and LaTeX should be referred to manuals or books. 
  Send any bug reports of the class file and the bibtex files to the below e-mail address

       	      	    	  E-mail: comex@ieice.org
			  IEICE publishing office.
